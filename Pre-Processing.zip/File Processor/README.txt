Below I will describe the classes used in this source file, along with the input. 
All files require a text file to read, and will return a new text file. Names of these files can be changed in the BufferedReader and FileWriter Instances for each class.

1. All_To_Lower_Case
	Input: File with text. No special requirements for it. 
	Output: all text within the file will be turned to lower case, and be re-written in a new text file.
	
	
2. Business_Count
	Input: List of processed business dataset. (created by Buissness_classify) List of categories found in desired state (created by State_and_Categories)
			Note: State can be changed in code from the variable String state.
	Output: For state given, gives a count of business found for each category stated in the category text.
	
3. Buissness_classify
	Input: Business dataset. 
		NOTE: Necessary for the dataset to include the words "full_address", "categories", "state", and "stars" as they are used to find the substrings from the dataset.
	Output: List of business, with their respective categories, and the state they belong to. 

4. Business_List
	Input: Business dataset.
	Output: Based on the three string variables of City, State, and Category, returns list of all businessID's that have these three requirements.

5. Count_Cities
	Input: Business dataset.
	Output: Given a state (String variable), counts the occurences of all the cities associated with that state.
	
6. End Stop Words
	Input: ArrayList of Strings
	Output: ArrayList of strings without punctuation or stop words (words predetermined, and can be changed)

7. Files_By_Keywords
	Input: List of keywords to look for. Five Files with reviews. (Each File is consiered to be part of a score 1,2,3,4,or5)
	Output: Two text files. One with the class of the reviews in order, 
			the second one containing a matrix the size of the number of keywords given. Each row is a review, and each column is a keyword. The value states the number of times that feature appears in the review
			
8. Files_By_Keywords_Binary
	Input: List of keywords to look for. Five Files with reviews. (Each File is consiered to be part of a score 1,2,3,4,or5)
	Output: Two text files. One with the class of the reviews in order, 
			the second one containing a matrix the size of the number of keywords given. Each row is a review, and each column is a keyword. The value states wether the feature appeared in the review (1) or not (0)

9. Pick_Words_Above_TFIDF_Threshold
	Input: Five files. Each with it's set of features, with their TF-IDF double value beside it (separated by a space) 
	Output: Returns the average Value for each word for all features in all five text files.
	
10. Read_and_Write
	Input: review Dataset (Composed only of Star Rating and Review, separated by a comma.
		Note: Format of Reviews: {"Star": (Score of Review), "Text": (Review)}
	output: Two files, one with the score of all reviews in order they appear, second being every review available. 
			
			
11. Review_Select
	Input: List of Business (From Business_List), List of reviews
			Note: Format of reviews: {"text": (review text), "business_id" : (id)}
	Output: All Reviews that are associated with the list of Business ID's given.
	
12. Separate_Keywords
	Input: Five Text Files.
	Output: All words found in the text files in a single list. (Each Word only listed once)

13. Separate_To_File
	Input: A text of Reviews
			Note: Reviews have to be in the form of: {"stars": (number of stars), "text": (text review)}
	Output: Five separate files, each file contains a set of reviews that belong to the same star rating. 
			In other words, the first file will have reviews of score one, the second of score two, the third of score three, the fourth of score four, and the fifth of score five.
			
14. State_and_Categories
	Input: A text of processed businesses.
		Note: Business file should be of format: "business_id": (id of business), "categories" :[(categories)] "state": (state of business)
	Output: Two files, each file containing a list of all categories in the dataset, and the other file containing a list of all states in the dataset.
	
15. State_Count
	Input: Business dataset
	Output: For each state (found in State_and_Categories), count the number of times each state appears in the dataset.
		Notes: we assume each business instance is unique, therefore it will return the number of business in each state.
	
16. Stop_Words_Project
	Input: A text file 
	Output: Using the class End_Stop_Words, a new text file with the same text, but with stop words removed entirely.
	
17. Taking_out_Training_Data
	Input: Five text files, each one with a set of reviews (from Separate_to_File)
	Output: Two files. One will be composed of 500 reviews, one from each of review. 
			Second file will contain the rest of the reviews, this file is used for testing for Naive Bayes.
			Text files return in same format as File_By_Keywords
		
18. Taking_out_Training_Data_Binary
	Input: Five text files, each one with a set of reviews (from Separate_to_File)
	Output: Two files. One will be composed of 500 reviews, one from each of review. 
			Second file will contain the rest of the reviews, this file is used for testing for Naive Bayes.
			Text files return in same format as File_By_Keywords_Binary
		