import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Hashtable;


public class Pick_Words_Above_TFIDF_Threshold {

	
	public static void main(String[] args) throws IOException{
		Hashtable<String, Double> keywords1 = new Hashtable<String,Double>();
		Hashtable<String, Double> keywords2 = new Hashtable<String,Double>();
		Hashtable<String, Double> keywords3 = new Hashtable<String,Double>();
		Hashtable<String, Double> keywords4 = new Hashtable<String,Double>();
		Hashtable<String, Double> keywords5 = new Hashtable<String,Double>();
		HashSet<String> set1 = new HashSet<String>();
		FileReader fr1 = new FileReader(new File("Score1-tfidf.txt"));
		FileReader fr2 = new FileReader(new File("Score2-tfidf.txt"));
		FileReader fr3 = new FileReader(new File("Score3-tfidf.txt"));
		FileReader fr4 = new FileReader(new File("Score4-tfidf.txt"));
		FileReader fr5 = new FileReader(new File("Score5-tfidf.txt"));
		
		BufferedReader bf1 = new BufferedReader(fr1);
		BufferedReader bf2 = new BufferedReader(fr2);
		BufferedReader bf3 = new BufferedReader(fr3);
		BufferedReader bf4 = new BufferedReader(fr4);
		BufferedReader bf5 = new BufferedReader(fr5);
		

		//part 1
		String line = bf1.readLine();
		while(line != null){
			String[] split = line.split(" ");
			double tfidf = Double.parseDouble(split[1]);
			keywords1.put(split[0], tfidf);
			set1.add(split[0]);
			
			line = bf1.readLine();
		}	
		
		//part2
		line = bf2.readLine();
		while(line != null){
			String[] split = line.split(" ");
			double tfidf = Double.parseDouble(split[1]);
			keywords2.put(split[0], tfidf);
			set1.add(split[0]);
			
			line = bf2.readLine();
		}
		
		//part 3
		line = bf3.readLine();
		while(line != null){
			String[] split = line.split(" ");
			double tfidf = Double.parseDouble(split[1]);
			keywords3.put(split[0], tfidf);
			set1.add(split[0]);
			
			line = bf3.readLine();
		}
		
		//part 4
		line = bf4.readLine();
		while(line != null){
			String[] split = line.split(" ");
			double tfidf = Double.parseDouble(split[1]);
			keywords4.put(split[0], tfidf);
			set1.add(split[0]);
			
			line = bf4.readLine();
		}
		
		
		//part 5
		line = bf5.readLine();
		while(line != null){
			String[] split = line.split(" ");
			double tfidf = Double.parseDouble(split[1]);
			keywords5.put(split[0], tfidf);
			set1.add(split[0]);
			
			line = bf5.readLine();
		}
		FileWriter text = new FileWriter("TF-IDF-Averages.txt");
		for(String word:set1){
			double d1= 0;
			double d2 = 0;
			double d3 = 0;
			double d4 = 0;
			double d5 = 0;
			if(keywords1.containsKey(word))
				d1 = keywords1.get(word);
			if(keywords2.containsKey(word))
			 d2 = keywords2.get(word);
			if(keywords3.containsKey(word))
			 d3 = keywords3.get(word);
			if(keywords4.containsKey(word))
			 d4 = keywords4.get(word);
			if(keywords5.containsKey(word))
			 d5 = keywords5.get(word);
			
			double avg = (d1+d2+d3+d4+d5)/5;
			
			text.write(word + " " + avg+"\n");
		}
		
		text.close();
		bf5.close();
		bf4.close();
		bf3.close();
		bf2.close();
		bf1.close();
		
		
		
	}
}
