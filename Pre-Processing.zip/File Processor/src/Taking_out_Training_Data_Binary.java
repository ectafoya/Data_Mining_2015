import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Taking_out_Training_Data_Binary {
	
	public static void main(String[] args) throws IOException{
		FileReader fr = new FileReader(new File("100Keywords.txt"));
		int score = 1;
		BufferedReader bf = new BufferedReader(fr);
		ArrayList<String> words = new ArrayList<String>();
		
		String line = bf.readLine();
		
		while(line !=null){
			words.add(line);
			line = bf.readLine();
		}
		
		
		bf.close();
		System.out.println("Reading Reviews 1");
		ArrayList<int[]> samples= new ArrayList<int[]>();
		ArrayList<int[]> tests = new ArrayList<int[]>();
		fr = new FileReader("ScoredWithoutStopWords1.txt");
		bf = new BufferedReader(fr);
		
		line = bf.readLine();
		int instance = 0;
		while(line !=null){
			String[] review = line.split(" ");
			int[] count = new int[words.size()+1];
			count[0] = score;
			
			//by frequency
			for(int i = 1; i<review.length;i++){
				if(!words.contains(review[i]))
					continue;
				int place = words.indexOf(review[i]);
				count[place+1]=1;
			}
			
			if(instance<100){
				tests.add(count);
			}
			else
				samples.add(count);		
			
			instance++;
			line = bf.readLine();
		}
		
		
		bf.close();
		score = 2;
		fr = new FileReader("ScoredWithoutStopWords2.txt");
		bf = new BufferedReader(fr);
		instance  = 0;
		line = bf.readLine();
		System.out.println("Reading Reviews 2");
		while(line !=null){
			String[] review = line.split(" ");
			int[] count = new int[words.size()+1];
			count[0] = score;
			
			//by frequency
			for(int i = 1; i<review.length;i++){
				if(!words.contains(review[i]))
					continue;
				int place = words.indexOf(review[i]);
				count[place+1]=1;
			}
			
			if(instance<100){
				tests.add(count);
			}
			else
				samples.add(count);	
			
			instance++;
			line = bf.readLine();
		}
		
		
		bf.close();
		score = 3;
		fr = new FileReader("ScoredWithoutStopWords3.txt");
		bf = new BufferedReader(fr);
		instance = 0;
		line = bf.readLine();
		System.out.println("Reading Reviews 3");
		while(line !=null){
			String[] review = line.split(" ");
			int[] count = new int[words.size()+1];
			count[0] = score;
			
			//by frequency
			for(int i = 1; i<review.length;i++){
				if(!words.contains(review[i]))
					continue;
				int place = words.indexOf(review[i]);
				count[place+1]=1;
			}
			
			
			if(instance<100){
				tests.add(count);
			}
			else
				samples.add(count);	
			instance++;
			line = bf.readLine();
		}
		
		bf.close();
		score = 4;
		fr = new FileReader("ScoredWithoutStopWords4.txt");
		bf = new BufferedReader(fr);
		instance = 0;
		line = bf.readLine();
		System.out.println("Reading Reviews 4");
		while(line !=null){
			String[] review = line.split(" ");
			int[] count = new int[words.size()+1];
			count[0] = score;
			
			//by frequency
			for(int i = 1; i<review.length;i++){
				if(!words.contains(review[i]))
					continue;
				int place = words.indexOf(review[i]);
				count[place+1]=1;
			}
			
			
			if(instance<100){
				tests.add(count);
			}
			else
				samples.add(count);		
			instance++;
			line = bf.readLine();
		}
		
		bf.close();
		score = 5;
		fr = new FileReader("ScoredWithoutStopWords5.txt");
		bf = new BufferedReader(fr);
		instance = 0;
		line = bf.readLine();
		System.out.println("Reading Reviews 5");
		while(line !=null){
			String[] review = line.split(" ");
			int[] count = new int[words.size()+1];
			count[0] = score;
			
			//by frequency
			for(int i = 1; i<review.length;i++){
				if(!words.contains(review[i]))
					continue;
				int place = words.indexOf(review[i]);
				count[place+1]=1;
			}
			
			
			if(instance<100){
				tests.add(count);
			}
			else
				samples.add(count);		
			instance++;
			line = bf.readLine();
		}
		
		bf.close();
		System.out.println("WRITING INTO FILE NOW");
		FileWriter arff_file = new FileWriter("5trainingData.txt");
		FileWriter scores = new FileWriter("5trainingLabels.txt");
		
		 for(int[] example:samples){
				scores.write(example[0]+"\n");
			  for(int i = 1; i<example.length-1; i++){
				 arff_file.write(example[i]+" ");
			 }
			 arff_file.write(example[example.length-1]+"\n");
		 }
		
		scores.close();		
		arff_file.close();
		FileWriter testData = new FileWriter("5testData.txt");
		FileWriter testLabel = new FileWriter("5testLabels.txt");
		for(int[] test:tests){
			testLabel.write(test[0]+"\n");
			for(int i = 1; i<test.length-1; i++){
				 testData.write(test[i]+" ");
			 }
			testData.write(test[test.length-1]+"\n");
		}
		
		testData.close();
		testLabel.close();
		
}
	
}
