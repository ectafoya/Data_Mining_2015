import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Read_and_Write {
public static void main(String[] args) throws IOException{
	FileReader fr = new FileReader(new File("processedRevs2.txt"));
	BufferedReader bf = new BufferedReader(fr);
	
	FileWriter scores = new FileWriter("scoresRevs2.txt");
	FileWriter text = new FileWriter("textRevs2.txt");
	
	String line = bf.readLine();
	
	while(line!=null){		
		//add whatever's missing from the string
		while(!line.contains("}")){
			String line1 = bf.readLine();
			line.concat(line1);
		}
		
		//split the string based on the : character
		String[] review = line.split(":");
		String score = review[1];
		String rev = review[2];
		
		
		
		review = score.split(",");
		score = review[0];
		
		if(!score.equals("\"")){
		scores.write(score + "\n");
		text.write(rev + "\n");
		}
		
		line = bf.readLine();
	}
	
	
	
	scores.close();
	text.close();
	bf.close();
}



}