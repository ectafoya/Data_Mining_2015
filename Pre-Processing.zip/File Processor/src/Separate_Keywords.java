import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;


public class Separate_Keywords {
	public static void main(String[] args) throws IOException{
		FileReader br = new FileReader(new File("ScoredWithoutStopWords5.txt"));
		BufferedReader b = new BufferedReader(br);
		FileWriter s1 = new FileWriter("Keyword_List.txt", true);
		HashSet<String> words = new HashSet<String>();
		
		String line = b.readLine();
		while(line != null){
			String[] w = line.split(" ");
			for(String s:w){
				words.add(s);
			}
			line = b.readLine();				
		}
		
		br = new FileReader(new File("ScoredWithoutStopWords1.txt"));
		b = new BufferedReader(br);
		while(line != null){
			String[] w = line.split(" ");
			for(String s:w){
				words.add(s);
			}
			line = b.readLine();				
		}
		
		br = new FileReader(new File("ScoredWithoutStopWords2.txt"));
		b = new BufferedReader(br);
		while(line != null){
			String[] w = line.split(" ");
			for(String s:w){
				words.add(s);
			}
			line = b.readLine();				
		}
		
		
		br = new FileReader(new File("ScoredWithoutStopWords3.txt"));
		b = new BufferedReader(br);
		while(line != null){
			String[] w = line.split(" ");
			for(String s:w){
				words.add(s);
			}
			line = b.readLine();				
		}
		
		br = new FileReader(new File("ScoredWithoutStopWords4.txt"));
		b = new BufferedReader(br);
		while(line != null){
			String[] w = line.split(" ");
			for(String s:w){
				words.add(s);
			}
			line = b.readLine();				
		}
		
		b.close();
		br.close();
		
		for(String s:words)
			s1.write(s + "\n");
		
		s1.close();
		
		
	}
	
}
