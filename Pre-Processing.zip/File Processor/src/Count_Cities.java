import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;


public class Count_Cities {

	public static void main(String[] args) throws IOException{
	FileReader fr = new FileReader(new File("buisness_dataset.txt"));
	BufferedReader bf = new BufferedReader(fr);
	HashSet<String> cities = new HashSet<String>();
	
	FileWriter write = new FileWriter("city_count.txt");
	
	String line = bf.readLine();
	while(line != null){
	if(line.contains("\"AZ\"")){
		int start = line.indexOf("city")+8;
		int end = line.indexOf(", \"review_count");
		
		
		String city = line.substring(start, end);
		cities.add(city);
		
		}
	
	line = bf.readLine();
	}
	
	System.out.println("Finished Reading the businesses!");
	
	fr.close();
	bf.close();
	int[] count = new int[cities.size()];
	bf = new BufferedReader(new FileReader(new File("buisness_dataset.txt")));
	line = bf.readLine();
	ArrayList<String> citi = new ArrayList<String>();
	for(String city:cities)
		citi.add(city);
	
	System.out.println("Counting the businesses!");
	while(line != null){
		for(int i = 0; i<citi.size(); i++)
			if(line.contains(citi.get(i)))
				count[i]++;
		line = bf.readLine();
		}
	bf.close();
	
	for(int i = 0; i<citi.size(); i++)
		write.write(citi.get(i) + " " + count[i]+ "\n");
	write.close();
	
	
	}
	
	
	}
