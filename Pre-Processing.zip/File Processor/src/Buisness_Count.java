import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class Buisness_Count {

	
	public static void main(String[] args) throws IOException{
		
		FileReader fr = new FileReader(new File("processed_buisness.txt"));
		FileReader cats = new FileReader(new File("categories.txt"));
		BufferedReader bf = new BufferedReader(fr);
		BufferedReader cat = new BufferedReader(cats);
		
		String state = "\"AZ\"";
		
		
		String line = cat.readLine();
		ArrayList<String> categories = new ArrayList<String>();
		while(line!=null){
			categories.add(line);
			line = cat.readLine();
		}
		cat.close();
		
		int[] cat_count = new int[categories.size()];
		
		line = bf.readLine();
		
		FileWriter business = new FileWriter("State_Business.txt");
		while(line!=null){
			if(line.contains(state)){
				business.write(line);
				for(int i = 0; i<categories.size(); i++){
					if(line.contains(categories.get(i)))					
					cat_count[i]++;
				}				
				business.write(line+"\n");
			}
			line = bf.readLine();
		}
		bf.close();
		business.close();

		FileWriter counts = new FileWriter("Business_Count.txt");
		for(int i = 0; i<categories.size(); i++){
			line = categories.get(i) + " " + cat_count[i] + "\n";
			counts.write(line);
		}
		counts.close();
		
	}
}
