import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Business_List {

	
	public static void main(String[] args) throws IOException{
		
		FileReader fr = new FileReader(new File("buisness_dataset.txt"));
		BufferedReader bf = new BufferedReader(fr);

		
		String state = "\"AZ\"";
		String category = "Restaurants";
		String city = "Phoenix";
		
		
		String line = bf.readLine();
		
		FileWriter business = new FileWriter("Business_List.txt");
		while(line!=null){
			if(line.contains(state) && line.contains(category) && line.contains(city)){
				String[] objects = line.split(" ");
				business.write(objects[1]+"\n");
			}
			line = bf.readLine();
		}
		business.close();
		bf.close();
	}
}
