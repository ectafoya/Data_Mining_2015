import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class Review_Select {
public static void main(String[] args) throws IOException{
	FileReader br = new FileReader(new File("Business_List.txt"));
	BufferedReader business = new BufferedReader(br);
	
	ArrayList<String> IDs = new ArrayList<String>();
	String line = business.readLine();
	
	while(line!= null){
		IDs.add(line);
		line = business.readLine();
	}
	business.close();
	System.out.println("Finished getting the ID!");
	
	
	FileReader fr = new FileReader(new File("RevsWithBusiness8.txt"));
	BufferedReader revs = new BufferedReader(fr);
	FileWriter decided = new FileWriter("ChosenRevs8.txt");
	line = revs.readLine();
	
	System.out.println("Walking into the ID contains!");
	while(line!=null){
		String b = line.split("\"business_id\": ")[1];
		b = b.split("}")[0];
		
		for(String s: IDs){
		if(s.contains(b)){
			decided.write(line+"\n");
		}	
		}
		
		
		
		line = revs.readLine();
	}
	System.out.println("FINISHED");
	revs.close();
	decided.close();
}
}
