import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;



public class State_Count {


	public static void main(String[] args) throws IOException{	
		FileReader fr = new FileReader(new File("processed_buisness.txt"));
		BufferedReader bf = new BufferedReader(fr);
		
	String[] wtv =  {"SC",
	                    "WA",
	                    "NV",
	                    "MN",
	                    "IL",
	                    "OR",
	                    "CA",
	                    "SCB",
	                    "AZ",
	                    "NC",
	                    "PA",
	                    "WI",
	                    "QC",
	                    "MA",
	                    "EDH",
	                    "XGL",
	                    "NW",
	                    "ELN",
	                    "KHL",
	                    "MLN",
	                    "HAM",
	                    "RP",
	                    "ON",
	                    "BW",
	                    "FIF",
	                    "NTH"};
	int[] state_count = new int[wtv.length];
	
	String line = bf.readLine();
	
	while(line!=null){
		System.out.println("1");
		String state = line.split("state")[1];
		
		for(int i = 0; i < wtv.length; i ++){
			if(state.contains(wtv[i])){
				state_count[i]++;
				break;
			}
		}//end for loop
		
		line = bf.readLine();
	}
	
	//print
	for(int i = 0; i<wtv.length; i++){
		System.out.println("State: " + wtv[i] + " Count: " + state_count[i]);
	}
	
	
	
	}
}
