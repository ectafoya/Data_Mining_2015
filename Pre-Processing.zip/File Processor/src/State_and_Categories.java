import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;


public class State_and_Categories {

	public static void main(String[] args) throws IOException{
		
		FileReader fr = new FileReader(new File("processed_buisness.txt"));
		BufferedReader bf = new BufferedReader(fr);
		
		FileWriter categories = new FileWriter("categories.txt");
		FileWriter states = new FileWriter("states.txt");
		
		HashSet<String> cats = new HashSet<String>();
		HashSet<String> states1 = new HashSet<String>();
		
		String line = bf.readLine();
		
		while(line!= null){
			String[] stuff1 = line.split("\\[");
			stuff1= stuff1[stuff1.length-1].split("\\]");
			String[] currentCats = stuff1[0].split(",");
			String[] ccats = stuff1[1].split(":");
			String currentState = ccats[ccats.length-1];
			
			 states1.add(currentState);
			
			for(String c:currentCats){
				c = c + "\n";
				cats.add(c); 
			}
			
			
			line = bf.readLine();
		}
		
		for(String c: cats){
			categories.write(c);
		}
		
		for(String s: states1){
			states.write(s + "\n");
		}
		
		categories.close();
		states.close();
	}
	
	
}
