import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class Buissness_classify{
	
	
	public static void main(String[] args) throws IOException{
	FileReader fr = new FileReader(new File("buisness_dataset.txt"));
	BufferedReader bf = new BufferedReader(fr);
	
	FileWriter write = new FileWriter("processed_buisness2.txt");
	
	
	String line = bf.readLine();
	
	while(line!= null){
		String business = "";

		int index_1 = line.indexOf("full_address");
		//adding the business id
		business= line.substring(15, index_1 -3);
		

		String line1 = line.substring(line.indexOf("categories")-1, line.indexOf("city")-3);

		business += " " + line1;
		

		line1 = line.substring(line.indexOf("state")-1, line.indexOf("stars")-3);

		  
		business+= " " + line1 + "\n";
		
		write.write(business);
		write.flush();
		line = bf.readLine();
	}
//	buisness_id -> full_address
//	categories -> city
//	state
	
	
	bf.close();
	write.close();
	}
}
