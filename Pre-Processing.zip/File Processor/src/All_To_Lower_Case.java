import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class All_To_Lower_Case{
public static void main(String[] args) throws IOException{
	FileReader br = new FileReader(new File("Score1.txt"));
	BufferedReader b = new BufferedReader(br);
	FileWriter s1 = new FileWriter("S1.txt", true);
	
	String line = b.readLine();
	
	while(line!=null){
		line = line.toLowerCase();
		s1.write(line+"\n");
		line = b.readLine();
	}
	
	b.close();
	s1.close();
	
}

}