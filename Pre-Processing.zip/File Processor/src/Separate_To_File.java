import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class Separate_To_File {
public static void main(String[] args) throws IOException{
	FileReader br = new FileReader(new File("ChosenRevs8.txt"));
	BufferedReader b = new BufferedReader(br);
	FileWriter s1 = new FileWriter("Score1.txt", true);
	FileWriter s2 = new FileWriter("Score2.txt", true);
	FileWriter s3 = new FileWriter("Score3.txt", true);
	FileWriter s4 = new FileWriter("Score4.txt", true);
	FileWriter s5 = new FileWriter("Score5.txt", true);
	
	String line = b.readLine();
	while(line != null){
		String[] rev = line.split(", \"business_id\": ")[0].split("\"text\": ");
		if(rev[0].contains("1"))
			s1.append(rev[1]+"\n");
		if(rev[0].contains("2"))
			s2.append(rev[1]+"\n");
		if(rev[0].contains("3"))
			s3.append(rev[1]+"\n");
		if(rev[0].contains("4"))
			s4.append(rev[1]+"\n");
		if(rev[0].contains("5"))
			s5.append(rev[1]+"\n");
		
		line = b.readLine();
	}
	
	s1.close();
	s2.close();
	s3.close();
	s4.close();
	s5.close();
	b.close();
}
}
