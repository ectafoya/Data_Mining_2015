import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class StopWordsProject {
	private static End_Stop_Words stop_words;
	
	public static void main(String[] args) throws IOException{
		
		stop_words = new End_Stop_Words();
		
		ArrayList<String> reviews = new ArrayList<String>();
		FileReader fr = new FileReader(new File("Score1.txt"));
		BufferedReader bf = new BufferedReader(fr);
		
		FileWriter text = new FileWriter("ScoredWithoutStopWords1.txt");
		
		String line = bf.readLine();

		while(line != null){
			reviews.add(line);
			line = bf.readLine();
		}
		
		System.out.println("Finished!" + reviews.size());
		ArrayList<String> swrem = stop_words.removeStopWordsAndPunctuationFromEssays(reviews);
		System.out.println("Removed Stopwords");
		for(String review: swrem){
			text.write(review + "\n");
		}
		
		System.out.println("Finished!");
		text.close();
		bf.close();
	}
	
	
}
