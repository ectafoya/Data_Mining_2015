Frequency = dlmread('TwentyPercentFrequency_MATLAB.txt');% [Y;Z];
Binary = dlmread('TwentyPercentBinary_MATLAB.txt');
VFrequency = dlmread('TwentyPercentScores_Frequency.txt');%cat(1,zeros(100,1),ones(100,1));
VBinary = dlmread('TwentyPercentScores_Binary.txt');
display('Running K Means');
[idxF, ctrsF, ssdF] = kmeans(Frequency, 5);
[idxB, ctrsB, ssdB] = kmeans(Binary, 5);

%[sF, hF] = silhouette(Frequency, idxF);
%[sB, hB] = silhouette(Binary, idxB);

%average_silhouette_Frequency = avgsilhouette(sF);
%average_silhouette_Binary = avgsilhouette(sB);
display('looking for randindx');
randindex_frequency = randinx(idxF, VFrequency);
randindex_binary = randinx(idxB, VBinary);

display('FINISHED');
%display(randindex_frequency);
%display(randindex_binary);

display(average_silhouette_Frequency);
display(average_silhouette_Binary);