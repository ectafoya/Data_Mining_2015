function [ avg ] = avgsilhouette(sil)

sum = 0;
count = 0;
for( i = 1:length(sil))
    sum = sum + sil(i);
    count = count + 1;
end
avg = sum/count;
end