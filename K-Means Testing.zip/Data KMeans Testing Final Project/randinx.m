function [ Rand ] = randinx( idx, V1 )
%UNTITLED3 Summary of this function goes here
TP = 0;
TN = 0;
count = 0;

for i = 1:length(V1)
    for j = i+1: length(V1)
       if(idx(i) == idx(j) && V1(i) == V1(j))
           TP = TP+1;
       end
       if(idx(i) ~= idx(j) && V1(i) ~= V1(j))
           TN = TN+1;
       end
       count = count+1;
    end
end
%   Detailed explanation goes here
Rand = (TP+TN)/count;

end

