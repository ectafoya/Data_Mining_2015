Files included:
KMeans_Test
Input: text file with an NxK matrix, where N and K do not have to be the same the same number.
	Also necessary, a separate file with the scores associated with each row.
Output: Perform K-Means Test, with cluster size of Five. Returns the Rand-Index for each test. Performs both frequency and Binary tests at the same time.
	Can also return the average silhouette from it, but at present those are commented out. Removing the % mark before the actions will allow one to also get the average silhouette.

randinx
	Input: Index from K-Means, V-vector with actual score
	Output: Rand-Index of the K-Means clustering.

avgsilhouette
	Input: silhouette vector from silhouette function of matlab
	Output: Average silhouette
